# Security Policy

## Supported Versions

The latest versions of both v2.9.x and v3.0.x are supported.

## Reporting a Vulnerability

For information on how to report a security issue, please see https://github.com/owasp-modsecurity/ModSecurity#security-issue
